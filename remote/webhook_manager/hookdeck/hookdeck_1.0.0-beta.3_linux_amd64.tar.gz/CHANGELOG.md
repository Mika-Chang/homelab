# Changelog

## 0.9.2 - 2024-05-03

No changes. Update to the build process to fix Linux builds.

## 0.9.1 - 2024-05-02

No changes. Just bumping the NPM version.

## 0.9.0 - 2024-05-02

### Breaking changes

- The `workspace` command has been replaced with `project`

### Changes

- Uses the [Hookdeck Go SDK](https://github.com/hookdeck/hookdeck-go-sdk)